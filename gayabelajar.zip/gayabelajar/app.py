import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, session
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

# Inisialisasi Flask App
app = Flask(__name__)
app.secret_key = 'your_super_secret_key'  # Ganti dengan kunci rahasia yang kuat

# Fungsi untuk terhubung ke database
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Dekorator untuk mengecek apakah user sudah login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('Silakan login terlebih dahulu.', 'danger')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# --- Rute-rute Otentikasi ---

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['logged_in'] = True
            session['username'] = user['username']  # <-- BARIS BARU: Simpan username ke sesi
            flash('Login berhasil!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Username atau password salah.', 'danger')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        hashed_password = generate_password_hash(password)
        
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password) VALUES (?, ?)',
                         (username, hashed_password))
            conn.commit()
            flash('Akun berhasil dibuat! Silakan login.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username sudah ada.', 'danger')
        finally:
            conn.close()
            
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    session.pop('username', None)  # <-- BARIS BARU: Hapus username dari sesi
    flash('Anda telah logout.', 'success')
    return redirect(url_for('login'))

# --- Rute-rute Aplikasi Utama ---

@app.route('/')
@login_required
def index():
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    # BARU: Meneruskan username ke template
    username = session.get('username')
    return render_template('dashboard.html', username=username)

@app.route('/data_siswa', methods=['GET', 'POST'])
@login_required
def data_siswa():
    conn = get_db_connection()
    search_query = request.args.get('search', '')
    
    if search_query:
        siswa = conn.execute("SELECT * FROM siswa WHERE nama LIKE ? OR jurusan LIKE ? OR kelas LIKE ? ORDER BY id ASC", 
                             ('%' + search_query + '%', '%' + search_query + '%', '%' + search_query + '%')).fetchall()
    else:
        siswa = conn.execute('SELECT * FROM siswa ORDER BY id ASC').fetchall()
    
    conn.close()
    return render_template('data_siswa.html', siswa=siswa, search_query=search_query)

# Rute baru untuk mencetak data siswa
@app.route('/print_data_siswa')
@login_required
def print_data_siswa():
    conn = get_db_connection()
    siswa = conn.execute('SELECT * FROM siswa ORDER BY id ASC').fetchall()
    conn.close()
    
    # BARU: Meneruskan username dari sesi ke template
    return render_template('print_data_siswa.html', siswa=siswa, username=session.get('username'))

@app.route('/input_siswa', methods=['GET', 'POST'])
@login_required
def input_siswa():
    if request.method == 'POST':
        nama = request.form['nama']
        jenis_kelamin = request.form['jenis_kelamin']
        poin_v = request.form['poin_v']
        poin_a = request.form['poin_a']
        poin_k = request.form['poin_k']
        jurusan = request.form['jurusan']
        kelas = request.form['kelas']

        conn = get_db_connection()
        conn.execute('INSERT INTO siswa (nama, jenis_kelamin, poin_v, poin_a, poin_k, jurusan, kelas) VALUES (?, ?, ?, ?, ?, ?, ?)',
                     (nama, jenis_kelamin, poin_v, poin_a, poin_k, jurusan, kelas))
        conn.commit()
        conn.close()
        flash('Data siswa berhasil ditambahkan!', 'success')
        return redirect(url_for('data_siswa'))
    return render_template('input_siswa.html')

@app.route('/edit_siswa/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_siswa(id):
    conn = get_db_connection()
    siswa = conn.execute('SELECT * FROM siswa WHERE id = ?', (id,)).fetchone()

    if request.method == 'POST':
        nama = request.form['nama']
        jenis_kelamin = request.form['jenis_kelamin']
        poin_v = request.form['poin_v']
        poin_a = request.form['poin_a']
        poin_k = request.form['poin_k']
        jurusan = request.form['jurusan']
        kelas = request.form['kelas']

        conn.execute('UPDATE siswa SET nama = ?, jenis_kelamin = ?, poin_v = ?, poin_a = ?, poin_k = ?, jurusan = ?, kelas = ? WHERE id = ?',
                     (nama, jenis_kelamin, poin_v, poin_a, poin_k, jurusan, kelas, id))
        conn.commit()
        conn.close()
        flash('Data siswa berhasil diubah!', 'success')
        return redirect(url_for('data_siswa'))

    conn.close()
    return render_template('edit_siswa.html', student=siswa)

@app.route('/hapus_siswa/<int:id>', methods=['POST'])
@login_required
def hapus_siswa(id):
    conn = get_db_connection()
    conn.execute('DELETE FROM siswa WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    flash('Data siswa berhasil dihapus!', 'success')
    return redirect(url_for('data_siswa'))

@app.route('/grafik')
@login_required
def grafik():
    conn = get_db_connection()
    data = conn.execute('SELECT SUM(poin_v) as total_v, SUM(poin_a) as total_a, SUM(poin_k) as total_k FROM siswa').fetchone()
    conn.close()

    labels = ['Visual', 'Auditori', 'Kinestetik']
    data_values = [data['total_v'], data['total_a'], data['total_k']]

    return render_template('grafik.html', labels=labels, data=data_values)

if __name__ == '__main__':
    app.run(debug=True)

