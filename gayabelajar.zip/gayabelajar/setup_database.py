import sqlite3

# Menghubungkan ke database SQLite (akan membuat file jika belum ada)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Membuat tabel users untuk menyimpan data pengguna
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL
    )
''')

# Membuat tabel siswa untuk menyimpan data siswa
cursor.execute('''
    CREATE TABLE IF NOT EXISTS siswa (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nama TEXT NOT NULL,
        jenis_kelamin TEXT,
        poin_v INTEGER,
        poin_a INTEGER,
        poin_k INTEGER,
        jurusan TEXT,
        kelas TEXT
    )
''')

# Menyimpan perubahan dan menutup koneksi
conn.commit()
conn.close()

print("Database dan tabel berhasil dibuat.")
